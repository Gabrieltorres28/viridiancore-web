"use client"

import { ArrowUpRight, MessageCircle } from "lucide-react"
import { Logo } from "./logo"
import { HeroVideo } from "./hero-video"

const WHATSAPP_URL = "https://wa.me/5490000000000"

export function Hero() {
  return (
    <section
      id="inicio"
      className="relative isolate flex min-h-[100svh] w-full items-center overflow-hidden bg-background"
    >
      {/* Background video — client-side source swapping for reliable desktop/mobile behavior */}
      <div
        className="absolute inset-0 -z-20 overflow-hidden"
        aria-hidden="true"
      >
        <HeroVideo
          desktopSrc="/videos/hero-desktop.mp4"
          mobileSrc="/videos/hero-mobile.mp4"
          poster="/images/hero-poster.jpg"
        />
      </div>

      {/* Dark overlay stack — ensures readability over any video */}
      <div
        className="absolute inset-0 -z-10 bg-background/55"
        aria-hidden="true"
      />
      <div
        className="absolute inset-0 -z-10 bg-gradient-to-b from-background/70 via-background/30 to-background"
        aria-hidden="true"
      />
      <div
        className="absolute inset-0 -z-10 hero-vignette"
        aria-hidden="true"
      />
      {/* Viridian wash — extremely subtle */}
      <div
        className="absolute inset-0 -z-10 mix-blend-overlay opacity-40 bg-[radial-gradient(60%_50%_at_20%_30%,color-mix(in_oklch,var(--viridian)_25%,transparent)_0%,transparent_60%)]"
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-10 mx-auto w-full max-w-7xl px-6 pt-32 pb-20 md:px-10 md:pt-40 md:pb-28">
        {/* Logo placeholder slot in hero */}
        <div className="mb-10 flex items-center gap-3 md:mb-14">
          <Logo size={40} />
          <div className="h-px w-16 bg-gradient-to-r from-viridian/60 to-transparent" />
        </div>

        {/* Eyebrow */}
        <div className="mb-6 inline-flex items-center gap-3 rounded-full border border-border/60 bg-card/30 px-4 py-1.5 backdrop-blur-sm">
          <span className="h-1.5 w-1.5 rounded-full bg-viridian shadow-[0_0_12px_var(--viridian)]" />
          <span className="text-xs font-medium uppercase tracking-[0.22em] text-foreground/80">
            Infraestructura digital
          </span>
        </div>

        {/* Main heading */}
        <h1 className="max-w-4xl text-balance font-sans text-4xl font-medium leading-[1.05] tracking-tight text-foreground sm:text-5xl md:text-6xl lg:text-7xl">
          Sistemas y software para{" "}
          <span className="text-viridian">operaciones reales</span>
        </h1>

        {/* Supporting paragraph */}
        <p className="mt-7 max-w-2xl text-pretty text-base leading-relaxed text-foreground/75 md:text-lg">
          Viridian Core desarrolla soluciones digitales para empresas e
          instituciones que necesitan estructura, control y una base
          tecnológica sólida. No vendemos humo: construimos sistemas,
          experiencias web y herramientas que ordenan procesos reales.
        </p>

        {/* CTAs */}
        <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
          <a
            href="#proyectos"
            className="group inline-flex items-center justify-center gap-2 rounded-md bg-viridian px-6 py-3.5 text-sm font-medium text-primary-foreground transition-all hover:bg-viridian/90 hover:shadow-[0_0_32px_-8px_var(--viridian)]"
          >
            Ver proyectos
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </a>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noreferrer"
            className="group inline-flex items-center justify-center gap-2 rounded-md border border-border/70 bg-card/40 px-6 py-3.5 text-sm font-medium text-foreground backdrop-blur-sm transition-all hover:border-viridian/50 hover:bg-card/60"
          >
            <MessageCircle className="h-4 w-4 text-viridian" />
            Hablar por WhatsApp
          </a>
        </div>

        {/* Trust / support line */}
        <p className="mt-8 max-w-xl text-sm text-foreground/55">
          Desarrollo web, software a medida y arquitectura digital aplicada.
        </p>

        {/* Corner marker — subtle indicator */}
        <div className="mt-16 flex items-center gap-6 border-t border-border/40 pt-6 font-mono text-[11px] uppercase tracking-[0.2em] text-foreground/50 md:mt-24">
          <span>V.CORE / 001</span>
          <span className="h-px flex-1 bg-border/40" />
          <span className="hidden sm:inline">Infra · Systems · Software</span>
        </div>
      </div>
    </section>
  )
}
