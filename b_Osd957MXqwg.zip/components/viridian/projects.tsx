import { ProjectCard, type Project } from "./project-card"

const PROJECTS: Project[] = [
  {
    index: "01",
    title: "El Alcázar",
    type: "Portal institucional",
    teaser:
      "Propuesta digital para una experiencia municipal más clara, moderna y accesible.",
    description:
      "Landing institucional orientada a modernizar la presencia digital del municipio, mejorar el acceso a información y ordenar la comunicación con el ciudadano.",
    tech: "Next.js · Tailwind · diseño responsive",
    href: "#",
  },
  {
    index: "02",
    title: "ISIPP",
    type: "Sitio institucional",
    teaser: "Presencia web profesional para una institución educativa.",
    description:
      "Sitio institucional diseñado para comunicar identidad, oferta académica e información clave con una estética moderna y estructura clara.",
    tech: "Next.js · Tailwind · enfoque institucional",
    href: "#",
  },
  {
    index: "03",
    title: "Blessed",
    type: "Sitio corporativo",
    teaser:
      "Web corporativa para una empresa de servicios con foco en imagen y claridad comercial.",
    description:
      "Landing profesional orientada a mejorar la presencia online de la marca, transmitir seriedad y facilitar contacto comercial.",
    tech: "Next.js · Tailwind · branding empresarial",
    href: "#",
  },
]

export function Projects() {
  return (
    <section
      id="proyectos"
      className="relative border-t border-border/50 bg-background py-24 md:py-36"
    >
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        {/* Section heading */}
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-viridian">
              / 002 — Proyectos
            </span>
            <h2 className="mt-4 text-balance text-3xl font-medium leading-[1.1] tracking-tight text-foreground md:text-5xl">
              Trabajos recientes de{" "}
              <span className="text-viridian">infraestructura aplicada</span>
            </h2>
          </div>
          <p className="max-w-md text-pretty text-sm leading-relaxed text-foreground/65 md:text-base">
            Una selección breve de proyectos públicos. Cada uno resuelve un
            problema concreto de comunicación, operación o presencia digital.
          </p>
        </div>

        {/* Separator */}
        <div className="mt-12 mb-10 h-px bg-gradient-to-r from-transparent via-border to-transparent" />

        {/* Cards grid */}
        <div className="grid gap-6 md:grid-cols-2 md:gap-7 lg:grid-cols-3">
          {PROJECTS.map((p) => (
            <ProjectCard key={p.index} project={p} />
          ))}
        </div>
      </div>
    </section>
  )
}
