"use client"

import { useEffect, useRef, useState } from "react"

type HeroVideoProps = {
  desktopSrc: string
  mobileSrc: string
  poster: string
  /**
   * Breakpoint in px. Below this we serve the mobile source. Defaults to 768.
   */
  breakpoint?: number
}

/**
 * Hero background video with proper desktop / mobile source swapping.
 *
 * Why not use <source media="..."> inside <video>?
 * The `media` attribute on <source> is only well-supported inside <picture>.
 * For <video>, browsers generally ignore it, so we drive the source from JS
 * via matchMedia for reliable behavior.
 *
 * - Autoplay, muted, loop, playsInline
 * - Poster image fallback is always present, preventing layout shift and
 *   giving us a solid, readable background before the video loads or when
 *   video is unavailable.
 * - Reloads the video only when the matching source actually changes.
 */
export function HeroVideo({
  desktopSrc,
  mobileSrc,
  poster,
  breakpoint = 768,
}: HeroVideoProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const [src, setSrc] = useState<string | null>(null)

  useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${breakpoint - 1}px)`)
    const pick = () => setSrc(mql.matches ? mobileSrc : desktopSrc)
    pick()
    mql.addEventListener("change", pick)
    return () => mql.removeEventListener("change", pick)
  }, [desktopSrc, mobileSrc, breakpoint])

  // When src changes, reload the video element so it picks up the new source.
  useEffect(() => {
    const v = videoRef.current
    if (!v || !src) return
    v.load()
    // Attempt autoplay after load; muted ensures this is allowed everywhere.
    const play = v.play()
    if (play && typeof play.catch === "function") {
      play.catch(() => {
        // Silently ignore — poster remains as a graceful fallback.
      })
    }
  }, [src])

  return (
    <video
      ref={videoRef}
      className="h-full w-full object-cover"
      autoPlay
      muted
      loop
      playsInline
      preload="metadata"
      poster={poster}
      // Avoid right-click downloads on the background asset
      controlsList="nodownload"
      disablePictureInPicture
      aria-hidden="true"
    >
      {src ? <source src={src} type="video/mp4" /> : null}
    </video>
  )
}
