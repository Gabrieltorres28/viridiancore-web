import { Building2, Cpu, Workflow, Network } from "lucide-react"
import type { LucideIcon } from "lucide-react"

type Service = {
  index: string
  title: string
  description: string
  icon: LucideIcon
}

const SERVICES: Service[] = [
  {
    index: "01",
    title: "Sitios institucionales",
    description:
      "Presencia digital seria para empresas, instituciones y organismos. Estructura clara, contenido ordenado y estética alineada con la marca.",
    icon: Building2,
  },
  {
    index: "02",
    title: "Sistemas a medida",
    description:
      "Software hecho a la medida de tu operación: gestión interna, paneles, flujos propios y herramientas que se adaptan al negocio, no al revés.",
    icon: Cpu,
  },
  {
    index: "03",
    title: "Automatización de procesos",
    description:
      "Integramos y automatizamos tareas repetitivas para reducir fricción, errores humanos y horas perdidas en trabajo manual innecesario.",
    icon: Workflow,
  },
  {
    index: "04",
    title: "Arquitectura digital",
    description:
      "Diseñamos la base tecnológica: stack, integraciones, datos y despliegue. Infraestructura pensada para durar y para escalar con criterio.",
    icon: Network,
  },
]

export function Services() {
  return (
    <section
      id="que-hacemos"
      className="relative overflow-hidden border-t border-border/50 bg-background py-24 md:py-36"
    >
      {/* Subtle grid backdrop */}
      <div
        className="pointer-events-none absolute inset-0 grid-backdrop opacity-50"
        aria-hidden="true"
      />

      <div className="relative mx-auto max-w-7xl px-6 md:px-10">
        <div className="max-w-3xl">
          <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-viridian">
            / 003 — Qué hacemos
          </span>
          <h2 className="mt-4 text-balance text-3xl font-medium leading-[1.1] tracking-tight text-foreground md:text-5xl">
            Servicios concretos, resultados medibles.
          </h2>
          <p className="mt-5 max-w-xl text-pretty text-base leading-relaxed text-foreground/65">
            No ofrecemos un catálogo genérico. Trabajamos en un set acotado de
            disciplinas donde podemos aportar criterio técnico real.
          </p>
        </div>

        <div className="mt-14 grid gap-px overflow-hidden rounded-lg border border-border/60 bg-border/60 md:grid-cols-2">
          {SERVICES.map((service) => {
            const Icon = service.icon
            return (
              <div
                key={service.index}
                className="group relative flex flex-col justify-between gap-10 bg-card p-8 transition-colors duration-500 hover:bg-card/70 md:p-10"
              >
                {/* top viridian accent bar */}
                <span
                  className="pointer-events-none absolute left-0 top-0 h-px w-0 bg-viridian transition-all duration-500 group-hover:w-full"
                  aria-hidden="true"
                />

                <div className="flex items-start justify-between">
                  <div className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-border/70 bg-background/60 text-viridian transition-colors duration-500 group-hover:border-viridian/50">
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-foreground/45">
                    {service.index}
                  </span>
                </div>

                <div>
                  <h3 className="text-xl font-medium tracking-tight text-foreground md:text-2xl">
                    {service.title}
                  </h3>
                  <p className="mt-3 max-w-md text-pretty text-sm leading-relaxed text-foreground/65 md:text-base">
                    {service.description}
                  </p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
