import Link from "next/link"
import { Instagram, Linkedin, MessageCircle } from "lucide-react"
import { Logo } from "./logo"

const WHATSAPP_URL = "https://wa.me/5490000000000"

const FOOTER_LINKS = [
  { href: "#inicio", label: "Inicio" },
  { href: "#proyectos", label: "Proyectos" },
  { href: "#que-hacemos", label: "Qué hacemos" },
  { href: "#enfoque", label: "Enfoque" },
]

export function Footer() {
  return (
    <footer className="border-t border-border/60 bg-background">
      <div className="mx-auto max-w-7xl px-6 py-16 md:px-10 md:py-20">
        <div className="grid gap-12 md:grid-cols-12">
          {/* Brand block */}
          <div className="md:col-span-5">
            <Link href="#inicio" className="flex items-center gap-3">
              <Logo size={36} />
              <span className="text-sm font-medium uppercase tracking-[0.22em] text-foreground/90">
                Viridian Core
              </span>
            </Link>
            <p className="mt-5 max-w-sm text-pretty text-sm leading-relaxed text-foreground/60">
              Sistemas y software para empresas e instituciones.
            </p>
          </div>

          {/* Nav */}
          <div className="md:col-span-4">
            <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-foreground/50">
              Navegación
            </span>
            <ul className="mt-5 grid grid-cols-2 gap-3">
              {FOOTER_LINKS.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="text-sm text-foreground/75 transition-colors hover:text-viridian"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact + Social */}
          <div className="md:col-span-3">
            <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-foreground/50">
              Contacto
            </span>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noreferrer"
              className="mt-5 inline-flex items-center gap-2 text-sm text-foreground/85 transition-colors hover:text-viridian"
            >
              <MessageCircle className="h-4 w-4 text-viridian" />
              WhatsApp
            </a>
            <div className="mt-6 flex items-center gap-2">
              <a
                href="#"
                aria-label="Instagram"
                className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border/60 bg-card/40 text-foreground/70 transition-colors hover:border-viridian/40 hover:text-viridian"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href="#"
                aria-label="LinkedIn"
                className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border/60 bg-card/40 text-foreground/70 transition-colors hover:border-viridian/40 hover:text-viridian"
              >
                <Linkedin className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-border/50 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-foreground/45">
            © {new Date().getFullYear()} Viridian Core — Todos los derechos
            reservados.
          </p>
          <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-foreground/45">
            Infra · Systems · Software
          </p>
        </div>
      </div>
    </footer>
  )
}
