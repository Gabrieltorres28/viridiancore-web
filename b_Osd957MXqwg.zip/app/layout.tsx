import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const geist = Geist({
  subsets: ["latin"],
  variable: "--font-geist-sans",
  display: "swap",
})

const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Viridian Core — Sistemas y software para operaciones reales",
  description:
    "Viridian Core desarrolla infraestructura digital, sistemas a medida y software aplicado para empresas e instituciones. Estructura, control y tecnología sólida.",
  generator: "v0.app",
  keywords: [
    "Viridian Core",
    "software a medida",
    "infraestructura digital",
    "sistemas",
    "desarrollo web",
    "automatización",
    "Next.js",
  ],
  openGraph: {
    title: "Viridian Core — Infraestructura digital",
    description:
      "Sistemas, software a medida y arquitectura digital aplicada para empresas e instituciones.",
    type: "website",
  },
}

export const viewport: Viewport = {
  themeColor: "#0a0b0c",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="es"
      className={`${geist.variable} ${geistMono.variable} dark bg-background`}
    >
      <body className="font-sans antialiased bg-background text-foreground">
        {children}
        {process.env.NODE_ENV === "production" && <Analytics />}
      </body>
    </html>
  )
}
