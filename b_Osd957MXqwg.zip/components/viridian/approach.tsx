import { Check } from "lucide-react"

const BULLETS = [
  "Menos improvisación",
  "Más estructura",
  "Tecnología aplicada",
  "Soluciones pensadas para operar",
]

export function Approach() {
  return (
    <section
      id="enfoque"
      className="relative border-t border-border/50 bg-background py-24 md:py-36"
    >
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          {/* LEFT — copy */}
          <div className="lg:col-span-7">
            <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-viridian">
              / 004 — Enfoque
            </span>
            <h2 className="mt-4 text-balance text-3xl font-medium leading-[1.08] tracking-tight text-foreground md:text-5xl lg:text-6xl">
              El problema no es el esfuerzo.{" "}
              <span className="text-viridian">Es la falta de sistema.</span>
            </h2>
            <p className="mt-7 max-w-2xl text-pretty text-base leading-relaxed text-foreground/70 md:text-lg">
              Muchas organizaciones trabajan más de lo necesario porque operan
              sin estructura digital real. Viridian Core nace para construir
              infraestructura digital útil: sistemas, sitios y herramientas que
              reduzcan fricción, ordenen procesos y generen control operativo.
            </p>

            <ul className="mt-10 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {BULLETS.map((b) => (
                <li
                  key={b}
                  className="flex items-center gap-3 rounded-md border border-border/60 bg-card/40 px-4 py-3 text-sm text-foreground/85 backdrop-blur-sm"
                >
                  <span className="inline-flex h-5 w-5 items-center justify-center rounded-full border border-viridian/40 bg-viridian/10 text-viridian">
                    <Check className="h-3 w-3" strokeWidth={3} />
                  </span>
                  {b}
                </li>
              ))}
            </ul>
          </div>

          {/* RIGHT — visual block */}
          <div className="lg:col-span-5">
            <div className="relative h-full min-h-[420px] overflow-hidden rounded-lg border border-border/60 bg-card">
              {/* Viridian wash */}
              <div
                className="pointer-events-none absolute inset-0 bg-[radial-gradient(80%_60%_at_80%_20%,color-mix(in_oklch,var(--viridian)_22%,transparent)_0%,transparent_60%)]"
                aria-hidden="true"
              />
              {/* Hairline grid */}
              <div
                className="pointer-events-none absolute inset-0 [background-image:linear-gradient(to_right,color-mix(in_oklch,var(--border)_60%,transparent)_1px,transparent_1px),linear-gradient(to_bottom,color-mix(in_oklch,var(--border)_60%,transparent)_1px,transparent_1px)] [background-size:56px_56px] opacity-60"
                aria-hidden="true"
              />

              <div className="relative flex h-full flex-col justify-between p-8 md:p-10">
                <div className="flex items-center justify-between text-xs font-mono uppercase tracking-[0.22em] text-foreground/55">
                  <span>System / overview</span>
                  <span className="inline-flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-viridian shadow-[0_0_10px_var(--viridian)]" />
                    live
                  </span>
                </div>

                <div className="space-y-5">
                  {/* Pseudo-metrics block */}
                  <div className="space-y-3">
                    {[
                      { label: "Estructura", value: 92 },
                      { label: "Automatización", value: 74 },
                      { label: "Control operativo", value: 88 },
                    ].map((row) => (
                      <div key={row.label}>
                        <div className="flex items-center justify-between text-xs text-foreground/65 font-mono">
                          <span>{row.label}</span>
                          <span>{row.value}%</span>
                        </div>
                        <div className="mt-1.5 h-[3px] w-full overflow-hidden rounded-full bg-border/60">
                          <div
                            className="h-full rounded-full bg-viridian"
                            style={{ width: `${row.value}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-border/60 pt-5">
                    <p className="text-sm leading-relaxed text-foreground/70">
                      Infraestructura pensada para que la operación tenga
                      criterio, no sólo esfuerzo.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
